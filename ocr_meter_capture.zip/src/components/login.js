import React, { useState } from "react";
// import "../style/login.css";
import '../assets/css/login.css'
// import { apiLogin } from "../api/Api.login";
import { useNavigate } from "react-router-dom";
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import axios from "axios";
import NavBarLogin from "./navbarlogin";
import { Helmet } from "react-helmet";


export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [error,setError]=useState(null)
  
  const [severity, setSeverity] = useState("success")

  const navigate=useNavigate()
  const handleUsernameChange = (event) => {
    setUsername(event.target.value);
  };

  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };
  const handleSnackbarOpen = (message, severity) => {
    setSnackbarMessage(message);
    setSeverity(severity); 
    setOpenSnackbar(true);
  };
  const handleSubmit = async(event) => {
    event.preventDefault();
    try {
      const result= await axios.post ("https://bpcl.connectingit.in/metcap/logIn",{
        email:username,
        password:password,
        loginfrom:'W',
        fcmtoken:'asfasfasf'
      }
    );
    console.log("response",result.data);
    console.log('token',result.data.token)
    localStorage.setItem('token', result.data.token);

    // localStorage.setItem('refreshToken', result.data.data.refreshToken);
    // localStorage.setItem('tokenExpiredAt', result.data.data.tokenExpiredAt);
    console.log("Submitted:", { username, password });
    if(result.data.statuscode===1){
      navigate("/home")
    }
    } catch (error) {
      console.error("Error adding Line:", error);
      handleSnackbarOpen("Error loggin in. Please try again.", "error");
    }
    
  };

  return (
    <div>
       <Helmet>
          <title>Admin Dashboard</title>
        </Helmet><NavBarLogin/>
    <div className="form-bg">
      <div className="container" style={{marginTop:'90px',marginBottom:'70px'}}>
        <div className="row">
          <div className="col-md-offset-4 col-md-4 col-sm-offset-3 col-sm-6">
            <div className="form-container">
              <div className="right-content">
                <h3 className="form-title">Login</h3>
                <form className="form-horizontal" onSubmit={handleSubmit}>
                  <div className="form-group">
                    <label>Username</label>
                    <input
                      type="text"
                      className="form-control"
                      value={username}
                      onChange={handleUsernameChange}
                      placeholder="Enter Username"
                    />
                  </div>
                  <div className="form-group">
                    <label>Password</label>
                    <input
                      type="password"
                      className="form-control"
                      value={password}
                      onChange={handlePasswordChange}
                      placeholder="Enter your password"
                    />
                  </div>
                  {/* <div className="remember-me">
                    <input type="checkbox" className="checkbox" />
                    <span className="check-label">Remember Me</span>
                  </div> */}
                  <a href="" className="forgot">
                    Forgot Password
                  </a>
                  <button type="submit" className="btn signin signinpointer">
                    Login
                  </button>
                  
                </form>
               
              </div>
            </div>
          </div>
        </div>
      </div>
      <Snackbar
  open={openSnackbar}
  autoHideDuration={6000}
  className="snackbar-right"
  onClose={() => setOpenSnackbar(false)}
>
  <MuiAlert
    onClose={() => setOpenSnackbar(false)}
    severity={severity} 
    sx={{ width: '100%' }}
  >
    {snackbarMessage}
  </MuiAlert>
</Snackbar>
    </div>
    </div>
  );
}