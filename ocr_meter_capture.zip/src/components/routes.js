import { BrowserRouter as Router,Routes,Route, } from "react-router-dom";
import Login from "./login";
import MyTask from "./home";
import VerifiedTask from "./verifiedtask";
import NavBar from "./navbar";
function MyRoutes(){
    return(
        <Router>
            {/* <NavBar/> */}
            <Routes>
                <Route path="/navbarr1231" element={<NavBar/>}/>
                <Route path="/login" element={<Login/>}/>
                <Route path="/home" element={<MyTask/>}/>
                <Route path="/verifiedtask" element={<VerifiedTask/>}/>

                <Route path="" element={<Login/>}/>

            </Routes>
        </Router>
    )
}

export default MyRoutes